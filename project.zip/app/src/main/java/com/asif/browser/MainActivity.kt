package com.asif.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var btnShield: TextView
    private lateinit var sp: SharedPreferences

    private val home = "file:///android_asset/home.html"
    private val blocked = AtomicInteger(0)
    private val allowedHttp = mutableSetOf<String>()
    private val allowedSusp = mutableSetOf<String>()
    private var desktop = false
    private var defaultUa = ""

    // ---- Security options: (key, label, blocked by default) ----
    private val opts = listOf(
        Triple("https_only", "🔒 Block unencrypted (HTTP) sites", true),
        Triple("ads", "🚫 Block ads & trackers", true),
        Triple("popups", "🪟 Block popups & auto-redirects", true),
        Triple("cookies3", "🍪 Block third-party cookies", true),
        Triple("phishing", "🎣 Warn on suspicious / phishing links", true),
        Triple("location", "📍 Block location access", false),
        Triple("cammic", "🎥 Block camera & microphone", false),
        Triple("downloads", "⬇️ Block all downloads", false),
        Triple("scripts", "⚙️ Block JavaScript (breaks many sites)", false)
    )

    private fun on(k: String) = sp.getBoolean(k, opts.first { it.first == k }.third)

    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "googletagmanager.com", "googletagservices.com", "adservice.google.com", "connect.facebook.net",
        "ads.twitter.com", "analytics.twitter.com", "taboola.com", "outbrain.com", "criteo.com",
        "criteo.net", "adnxs.com", "scorecardresearch.com", "hotjar.com", "mixpanel.com", "segment.io",
        "ads.yahoo.com", "moatads.com", "quantserve.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "adsrvr.org", "popads.net", "propellerads.com", "exoclick.com", "mgid.com",
        "amazon-adsystem.com", "adcolony.com", "unityads.unity3d.com", "applovin.com", "chartboost.com"
    )

    private val risky = setOf(
        "apk", "apks", "xapk", "exe", "msi", "bat", "cmd", "sh", "jar", "dex", "scr", "js", "vbs",
        "zip", "rar", "7z", "iso", "dmg"
    )

    // ---- Launchers ----
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        filePathCb = null
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private var onPerms: ((Map<String, Boolean>) -> Unit)? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { m ->
            onPerms?.invoke(m)
            onPerms = null
        }

    private fun withPerms(perms: Array<String>, cb: (Boolean) -> Unit) {
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) { cb(true); return }
        onPerms = { m -> cb(missing.all { m[it] == true }) }
        permLauncher.launch(missing.toTypedArray())
    }

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    // =====================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sp = getSharedPreferences("sec", Context.MODE_PRIVATE)
        window.statusBarColor = Color.parseColor("#0D1424")
        window.navigationBarColor = Color.parseColor("#0D1424")

        web = findViewById(R.id.webView)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        btnShield = findViewById(R.id.btnShield)
        defaultUa = web.settings.userAgentString
        WebView.setWebContentsDebuggingEnabled(false)

        setupWeb()
        applySettings()
        applyProxy()

        findViewById<View>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.btnHome).setOnClickListener { load(home) }
        findViewById<View>(R.id.btnReload).setOnClickListener { web.reload() }
        btnShield.setOnClickListener { securityCenter() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { menu() }

        urlBar.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                go(parse(urlBar.text.toString()))
                urlBar.clearFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(urlBar.windowToken, 0)
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustom()
                    web.canGoBack() -> web.goBack()
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        handleIntent(intent)
        askDefaultOnce()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        if (sp.getBoolean("private", false)) clearData()
        web.destroy()
        super.onDestroy()
    }

    // =====================================================
    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun setupWeb() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                gate(r.url)

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: return null
                if (on("ads") && isTracker(host)) {
                    blocked.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                v.settings.javaScriptEnabled = jsAllowed(url)
                updateShield(url)
                if (!urlBar.hasFocus()) urlBar.setText(if (url == null || isAsset(url)) "" else url)
            }

            override fun onPageFinished(v: WebView, url: String?) {
                if (url != null && url.startsWith("http") && !sp.getBoolean("private", false)) {
                    addTo("history", v.title ?: url, url, 200)
                }
            }

            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) {
                    v.loadDataWithBaseURL(
                        null, errorPage("Can't open this page", e.description.toString()),
                        "text/html", "utf-8", null
                    )
                }
            }

            override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: SslError) {
                h.cancel()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("🚫 Connection not private")
                    .setMessage("This site's security certificate is not valid. Loading was blocked to protect you.")
                    .setPositiveButton("OK", null).show()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }

            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    val cam = req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    val mic = req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if ((!cam && !mic) || on("cammic")) { req.deny(); return@runOnUiThread }
                    val what = listOfNotNull(if (cam) "camera" else null, if (mic) "microphone" else null)
                        .joinToString(" & ")
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("🔔 Permission request")
                        .setMessage("${req.origin.host} wants to use your $what. Allow only if you trust this site.")
                        .setPositiveButton("Allow") { _, _ ->
                            val p = mutableListOf<String>()
                            if (cam) p.add(Manifest.permission.CAMERA)
                            if (mic) p.add(Manifest.permission.RECORD_AUDIO)
                            withPerms(p.toTypedArray()) { ok ->
                                if (ok) req.grant(req.resources) else req.deny()
                            }
                        }
                        .setNegativeButton("Deny") { _, _ -> req.deny() }
                        .setOnCancelListener { req.deny() }
                        .show()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, cb: GeolocationPermissions.Callback
            ) {
                if (on("location")) { cb.invoke(origin, false, false); return }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("📍 Location request")
                    .setMessage("$origin wants to know your location. Allow?")
                    .setPositiveButton("Allow") { _, _ ->
                        withPerms(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) { ok ->
                            cb.invoke(origin, ok, false)
                        }
                    }
                    .setNegativeButton("Deny") { _, _ -> cb.invoke(origin, false, false) }
                    .setOnCancelListener { cb.invoke(origin, false, false) }
                    .show()
            }

            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) {
                    filePathCb = null; false
                }
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                (window.decorView as FrameLayout).addView(view)
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            }

            override fun onHideCustomView() = hideCustom()
        }

        web.setDownloadListener { url, ua, cd, mime, _ -> askDownload(url, ua, cd, mime) }
    }

    private fun hideCustom() {
        customView?.let { (window.decorView as FrameLayout).removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Suppress("DEPRECATION")
    private fun applySettings() {
        val s = web.settings
        s.javaScriptEnabled = jsAllowed(web.url)
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = !on("popups")
        s.setSupportMultipleWindows(false)
        s.setGeolocationEnabled(!on("location"))
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = desktop
        s.loadWithOverviewMode = desktop
        s.userAgentString = if (desktop)
            defaultUa.replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        else defaultUa
        val priv = sp.getBoolean("private", false)
        s.cacheMode = if (priv) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, !on("cookies3"))
        if (priv) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    // =====================================================
    // Navigation + security gate
    private fun isAsset(u: String?) = u?.startsWith("file:///android_asset/") == true
    private fun localUnsafe(u: String?) =
        u != null && (u.startsWith("content:") || (u.startsWith("file:") && !isAsset(u)))
    private fun jsAllowed(u: String?) = isAsset(u) || (!on("scripts") && !localUnsafe(u))
    private fun isTracker(h: String) = adHosts.any { h == it || h.endsWith(".$it") }

    private fun load(url: String) {
        web.settings.javaScriptEnabled = jsAllowed(url)
        web.loadUrl(url)
    }

    private fun go(url: String) {
        if (!gate(Uri.parse(url))) load(url)
    }

    /** returns true if navigation was blocked / handled here */
    private fun gate(u: Uri): Boolean {
        val s = (u.scheme ?: "").lowercase()
        val host = u.host ?: ""
        when (s) {
            "https" -> {}
            "http" -> if (on("https_only") && host !in allowedHttp) { askHttp(u); return true }
            "blob", "about" -> return false
            "file" -> if (!isAsset(u.toString())) { toast("🚫 Local file access blocked"); return true } else return false
            "javascript", "data", "intent" -> { toast("🚫 Blocked unsafe link type"); return true }
            else -> { askExternal(u); return true }
        }
        if (on("phishing") && host !in allowedSusp && suspicious(u)) { askSuspicious(u); return true }
        return false
    }

    private fun suspicious(u: Uri): Boolean {
        val h = u.host ?: return false
        if (u.userInfo != null) return true
        if (h.contains("xn--")) return true
        val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(h)
        return ip && !(h.startsWith("192.168.") || h.startsWith("10.") || h.startsWith("127."))
    }

    private fun askHttp(u: Uri) {
        val host = u.host ?: ""
        AlertDialog.Builder(this)
            .setTitle("⚠️ Not secure")
            .setMessage("$host uses HTTP (no encryption). Anyone on the network can see what you send or receive.")
            .setPositiveButton("Use HTTPS") { _, _ -> go(u.buildUpon().scheme("https").build().toString()) }
            .setNeutralButton("Open anyway") { _, _ -> allowedHttp.add(host); load(u.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askSuspicious(u: Uri) {
        val host = u.host ?: ""
        AlertDialog.Builder(this)
            .setTitle("🎣 Suspicious link")
            .setMessage("This address looks risky (hidden login part, look-alike characters, or raw IP):\n\n$u\n\nDo not enter passwords or card details here.")
            .setPositiveButton("Go back", null)
            .setNegativeButton("Continue anyway") { _, _ -> allowedSusp.add(host); load(u.toString()) }
            .show()
    }

    private fun askExternal(u: Uri) {
        AlertDialog.Builder(this)
            .setTitle("Open in another app?")
            .setMessage("This link wants to open another app:\n\n$u")
            .setPositiveButton("Open") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { toast("No app found") }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data
        if (i?.action == Intent.ACTION_VIEW && d != null) {
            when (d.scheme) {
                "http", "https" -> go(d.toString())
                "content", "file" -> openLocal(d)
                else -> if (web.url == null) load(home)
            }
        } else if (web.url == null) load(home)
    }

    private fun openLocal(d: Uri) {
        AlertDialog.Builder(this)
            .setTitle("⚠️ Security reminder")
            .setMessage("You are opening a file from outside the browser. Open it only if you trust the source. Scripts are turned off for this file.")
            .setPositiveButton("Open") { _, _ ->
                web.settings.javaScriptEnabled = false
                web.loadUrl(d.toString())
            }
            .setNegativeButton("Cancel") { _, _ -> if (web.url == null) load(home) }
            .setOnCancelListener { if (web.url == null) load(home) }
            .show()
    }

    private fun parse(t0: String): String {
        val t = t0.trim()
        if (t.isEmpty()) return home
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (!t.contains(" ") && t.contains(".")) return "https://$t"
        return "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    private fun updateShield(u: String?) {
        urlBar.hint = "Search or type URL"
        btnShield.text = when {
            u == null || isAsset(u) -> "🛡"
            u.startsWith("https") -> "🔒"
            u.startsWith("http") -> "⚠️"
            else -> "📄"
        }
    }

    // =====================================================
    // Downloads
    private fun askDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (on("downloads")) { toast("🚫 Downloads are blocked in Security Center"); return }
        if (!url.startsWith("http")) { toast("This download type is not supported"); return }
        val name = URLUtil.guessFileName(url, cd, mime)
        val ext = name.substringAfterLast('.', "").lowercase()
        val warn = if (ext in risky)
            "⚠️ DANGEROUS file type (.$ext). It can harm your phone or steal your data. Download only if you fully trust this site.\n\n"
        else "🔔 Security reminder: download files only from sources you trust.\n\n"
        AlertDialog.Builder(this)
            .setTitle(if (ext in risky) "⛔ Risky download" else "Download file?")
            .setMessage(warn + "File: $name\nFrom: ${Uri.parse(url).host}")
            .setPositiveButton("Download") { _, _ -> startDownload(url, ua, mime, name) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startDownload(url: String, ua: String?, mime: String?, name: String) {
        fun enqueue() {
            val r = DownloadManager.Request(Uri.parse(url))
            if (mime != null) r.setMimeType(mime)
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            if (ua != null) r.addRequestHeader("User-Agent", ua)
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            toast("⬇️ Downloading $name")
        }
        if (Build.VERSION.SDK_INT <= 28) {
            withPerms(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)) { ok ->
                if (ok) enqueue() else toast("Storage permission denied")
            }
        } else enqueue()
    }

    // =====================================================
    // Security Center
    private fun securityCenter() {
        val labels = opts.map { it.second }.toTypedArray()
        val checked = BooleanArray(opts.size) { on(opts[it].first) }
        val off = checked.count { !it }
        val score = (opts.size - off) * 100 / opts.size
        val status = if (off > 0) "⚠️ $off protection(s) OFF" else "✅ Fully protected"
        AlertDialog.Builder(this)
            .setTitle("🛡 Security $score%  •  ${blocked.get()} blocked\n$status")
            .setMultiChoiceItems(labels, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Save") { _, _ ->
                val e = sp.edit()
                opts.forEachIndexed { i, o -> e.putBoolean(o.first, checked[i]) }
                e.apply()
                applySettings()
                toast("Security saved")
                web.reload()
            }
            .setNeutralButton("Maximum 🔐") { _, _ ->
                val e = sp.edit()
                opts.forEach { e.putBoolean(it.first, true) }
                e.apply()
                applySettings()
                securityCenter()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =====================================================
    // Menu
    private fun menu() {
        val priv = sp.getBoolean("private", false)
        val items = arrayOf(
            "🛡 Security Center", "⭐ Add bookmark", "📚 Bookmarks", "🕘 History", "⬇️ Downloads",
            "🔍 Find in page", if (desktop) "📱 Mobile site" else "🖥 Desktop site",
            if (priv) "🕶 Private mode: ON" else "🕶 Private mode: OFF",
            "📤 Share", "📷 Scan QR", "🧹 Clear browsing data", "✅ Make default browser",
            if (sp.getBoolean("proxy_on", false)) "🌐 Hide my IP: ON" else "🌐 Hide my IP (Proxy)"
        )
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> securityCenter()
                1 -> {
                    val u = web.url
                    if (u != null && !isAsset(u)) { addTo("bookmarks", web.title ?: u, u, 500); toast("⭐ Saved") }
                }
                2 -> showList("⭐ Bookmarks", "bookmarks")
                3 -> showList("🕘 History", "history")
                4 -> try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { toast("Not available") }
                5 -> findDialog()
                6 -> { desktop = !desktop; applySettings(); web.reload() }
                7 -> {
                    sp.edit().putBoolean("private", !priv).apply()
                    applySettings()
                    toast(if (!priv) "🕶 Private mode ON (history off, screenshots blocked)" else "Private mode OFF")
                }
                8 -> {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, web.url ?: "")
                    startActivity(Intent.createChooser(send, "Share"))
                }
                9 -> GmsBarcodeScanning.getClient(this).startScan()
                    .addOnSuccessListener { b -> b.rawValue?.let { go(parse(it)) } }
                    .addOnFailureListener { toast("Scan failed") }
                10 -> AlertDialog.Builder(this).setTitle("Clear all browsing data?")
                    .setPositiveButton("Clear") { _, _ -> clearData(); toast("🧹 Cleared") }
                    .setNegativeButton("Cancel", null).show()
                11 -> makeDefault()
                12 -> proxyDialog()
            }
        }.show()
    }

    private fun findDialog() {
        val et = EditText(this)
        et.hint = "Find in page"
        web.setFindListener { active, count, done -> if (done) toast("$count found") }
        AlertDialog.Builder(this).setView(et)
            .setPositiveButton("Find") { _, _ -> web.findAllAsync(et.text.toString()) }
            .setNeutralButton("Next") { _, _ -> web.findNext(true) }
            .setNegativeButton("Close") { _, _ -> web.clearMatches() }.show()
    }

    // =====================================================
    // Bookmarks / history
    private fun loadList(k: String): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val a = JSONArray(sp.getString(k, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(o.getString("t") to o.getString("u"))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun saveList(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        sp.edit().putString(k, a.toString()).apply()
    }

    private fun addTo(k: String, t: String, u: String, max: Int) {
        val l = loadList(k)
        l.removeAll { it.second == u }
        l.add(0, t to u)
        saveList(k, l.take(max))
    }

    private fun showList(title: String, k: String) {
        val l = loadList(k)
        if (l.isEmpty()) { toast("Empty"); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(l.map { it.first.take(60) }.toTypedArray()) { _, i -> go(l[i].second) }
            .setNeutralButton("Clear all") { _, _ -> saveList(k, emptyList()) }
            .setNegativeButton("Close", null).show()
    }

    private fun clearData() {
        saveList("history", emptyList())
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        web.clearCache(true)
        web.clearHistory()
    }

    // =====================================================
    // Proxy / hide IP
    private fun applyProxy() {
        val isOn = sp.getBoolean("proxy_on", false)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            if (isOn) toast("Proxy is not supported on this phone's WebView")
            return
        }
        val ex = ContextCompat.getMainExecutor(this)
        val rule = sp.getString("proxy_rule", "") ?: ""
        if (isOn && rule.isNotBlank()) {
            // No direct fallback on purpose: if the proxy fails, pages fail to load instead of leaking your real IP.
            val cfg = ProxyConfig.Builder().addProxyRule(rule).build()
            ProxyController.getInstance().setProxyOverride(cfg, ex) { }
        } else {
            ProxyController.getInstance().clearProxyOverride(ex) { }
        }
    }

    private fun setProxy(rule: String) {
        sp.edit().putString("proxy_rule", rule).putBoolean("proxy_on", true).apply()
        applyProxy()
        toast("🌐 Proxy ON")
        web.reload()
    }

    private fun proxyDialog() {
        val isOn = sp.getBoolean("proxy_on", false)
        val items = arrayOf(
            if (isOn) "🟢 Proxy is ON (tap to turn off)" else "⚪ Proxy is OFF",
            "🧅 Use Tor (Orbot app must be running)",
            "✏️ Custom proxy / VPN server",
            "🔎 Check my IP"
        )
        AlertDialog.Builder(this).setTitle("🌐 Hide my IP")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> if (isOn) {
                        sp.edit().putBoolean("proxy_on", false).apply()
                        applyProxy(); toast("Proxy OFF"); web.reload()
                    } else toast("Choose Tor or Custom proxy below")
                    1 -> setProxy("socks5://127.0.0.1:9050")
                    2 -> customProxy()
                    3 -> go("https://api.ipify.org")
                }
            }.show()
    }

    private fun customProxy() {
        val et = EditText(this)
        et.hint = "socks5://1.2.3.4:1080"
        et.setText(sp.getString("proxy_rule", ""))
        AlertDialog.Builder(this).setTitle("Custom proxy")
            .setMessage("Format: socks5://host:port or http://host:port\n\n⚠️ A proxy can see your traffic. Use only a server you trust, not free public proxies.")
            .setView(et)
            .setPositiveButton("Connect") { _, _ ->
                val r = et.text.toString().trim()
                if (Regex("^(https?|socks5)://[^\\s:/]+:\\d{2,5}$").matches(r)) setProxy(r)
                else toast("Wrong format. Example: socks5://1.2.3.4:1080")
            }
            .setNegativeButton("Cancel", null).show()
    }

    // =====================================================
    // Default browser
    private fun makeDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleHeld(RoleManager.ROLE_BROWSER)) { toast("✅ Already your default browser"); return }
                if (rm.isRoleAvailable(RoleManager.ROLE_BROWSER)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_BROWSER)); return
                }
            }
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        } catch (e: Exception) { toast("Open Settings > Default apps > Browser app") }
    }

    private fun askDefaultOnce() {
        if (sp.getBoolean("asked_default", false)) return
        sp.edit().putBoolean("asked_default", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Make this your default browser?")
            .setMessage("Links from other apps will open here with all security protections.")
            .setPositiveButton("Yes") { _, _ -> makeDefault() }
            .setNegativeButton("Later", null).show()
    }

    // =====================================================
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun errorPage(t: String, d: String) =
        "<html><body style='background:#070b14;color:#e6f1ff;font-family:sans-serif;text-align:center;padding:60px 20px'>" +
            "<div style='font-size:56px'>🛡</div><h2>$t</h2><p style='color:#7d8ba8'>$d</p></body></html>"
}
