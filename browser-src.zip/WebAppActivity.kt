// NOTE: package line must match YOUR project's package name.
package com.asif.browser

import android.Manifest
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// "Add to Home screen" kora website ei activity-te app-er moto (address bar chara) khole.
class WebAppActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pending: ((Boolean) -> Unit)? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            pending?.invoke(r.values.all { it }); pending = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent?.data?.toString()
        if (url == null) {
            finish(); return
        }
        val root = FrameLayout(this).apply { fitsSystemWindows = true }
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true) // login (Firebase/Google) er jonno

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                if (s == "http" || s == "https" || s == "about" || s == "data") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, r.url))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: SslError) {
                h.cancel()
                Toast.makeText(this@WebAppActivity, "Certificate error, site block kora holo", Toast.LENGTH_LONG).show()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    picker.launch(params.createIntent()); true
                } catch (e: Exception) {
                    fileCb = null; false
                }
            }

            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    val cam = PermissionRequest.RESOURCE_VIDEO_CAPTURE
                    val mic = PermissionRequest.RESOURCE_AUDIO_CAPTURE
                    val needs = req.resources.filter { it == cam || it == mic }
                    if (needs.isEmpty()) {
                        req.deny(); return@runOnUiThread
                    }
                    val what = needs.joinToString(" + ") { if (it == cam) "camera" else "microphone" }
                    AlertDialog.Builder(this@WebAppActivity)
                        .setTitle(req.origin.host ?: "App")
                        .setMessage("Ei app $what use korte chay")
                        .setPositiveButton("Allow") { _, _ ->
                            val android = needs.map {
                                if (it == cam) Manifest.permission.CAMERA else Manifest.permission.RECORD_AUDIO
                            }.toTypedArray()
                            withPerms(android) { ok ->
                                if (ok) req.grant(needs.toTypedArray()) else req.deny()
                            }
                        }
                        .setNegativeButton("Block") { _, _ -> req.deny() }
                        .setOnCancelListener { req.deny() }
                        .show()
                }
            }
        }

        web.setDownloadListener { dl, ua, cd, mime, _ ->
            try {
                val name = URLUtil.guessFileName(dl, cd, mime)
                val req = DownloadManager.Request(Uri.parse(dl))
                    .setMimeType(mime)
                    .addRequestHeader("User-Agent", ua)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(dl) ?: "")
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Download shuru: $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download fail", Toast.LENGTH_SHORT).show()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.loadUrl(url)
    }

    private fun withPerms(p: Array<String>, cb: (Boolean) -> Unit) {
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) cb(true)
        else {
            pending = cb; permLauncher.launch(p)
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
