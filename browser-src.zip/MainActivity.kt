// NOTE: first line (package ...) must match YOUR project's package name.
package com.asif.browser

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Canvas
import android.graphics.Paint
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import android.app.KeyguardManager
import android.net.http.SslError
import android.os.Build
import android.os.SystemClock
import android.view.WindowManager
import android.webkit.SslErrorHandler
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import java.io.ByteArrayInputStream
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private class Tab(val web: WebView, val incognito: Boolean) {
        var title = "New tab"
        var flag = 0 // 0 normal, 1 blocked, 2 ssl error
        var icon: Bitmap? = null
        var blockedUrl: String? = null
    }

    private val HOME = "file:///android_asset/home.html"
    private val KHOJ_TPL = "https://itsaz724.github.io/Khoj/?q=%s"
    private val DESKTOP_UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val ADULT_WORDS = listOf(
        "porn", "xxx", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers"
    )

    private val TRACKERS = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "adservice.google.com", "criteo.com", "taboola.com", "outbrain.com", "adnxs.com",
        "scorecardresearch.com", "hotjar.com", "ads-twitter.com", "amazon-adsystem.com",
        "moatads.com", "popads.net", "propellerads.com", "adsterra.com", "exoclick.com"
    )
    private var unlocked = false
    private var locking = false
    private var stopAt = 0L

    private val tabs = mutableListOf<Tab>()
    private var cur = 0
    private var desktop = false
    private var dark = false
    private lateinit var defaultUA: String

    private lateinit var topBar: LinearLayout
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var tabCount: TextView
    private lateinit var star: TextView
    private lateinit var btnBack: TextView
    private lateinit var btnFwd: TextView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var secIcon: TextView

    private val prefs by lazy { getSharedPreferences("browser", Context.MODE_PRIVATE) }

    // ---- activity result launchers ----
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) openFile(u)
    }
    private var pendingPerm: ((Boolean) -> Unit)? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            pendingPerm?.invoke(r.values.all { it }); pendingPerm = null
        }

    private val lockLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            locking = false
            if (r.resultCode == RESULT_OK) {
                unlocked = true
                container.visibility = View.VISIBLE
            } else finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        defaultUA = WebSettings.getDefaultUserAgent(this)
        save("block", load("block").filter { it.first.isNotBlank() }) // faka entry clean
        CookieManager.getInstance().setAcceptCookie(prefs.getBoolean("cookies", true))

        topBar = findViewById(R.id.topBar)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.container)
        tabCount = findViewById(R.id.btnTabs)
        star = findViewById(R.id.btnStar)
        btnBack = findViewById(R.id.btnBack)
        btnFwd = findViewById(R.id.btnFwd)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        secIcon = findViewById(R.id.secIcon)
        secIcon.setOnClickListener { showSiteInfo() }
        applySecureFlag()

        urlBar.setOnEditorActionListener { _, id, e ->
            if (id == EditorInfo.IME_ACTION_GO || (e?.keyCode == KeyEvent.KEYCODE_ENTER && e.action == KeyEvent.ACTION_DOWN)) {
                go(urlBar.text.toString()); true
            } else false
        }
        findViewById<View>(R.id.btnReload).setOnClickListener { web().reload() }
        tabCount.setOnClickListener { showTabs() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu() }
        btnBack.setOnClickListener { if (web().canGoBack()) web().goBack() }
        btnFwd.setOnClickListener { if (web().canGoForward()) web().goForward() }
        findViewById<View>(R.id.btnHome).setOnClickListener { web().loadUrl(HOME) }
        star.setOnClickListener { toggleBookmark() }
        findViewById<View>(R.id.btnScan).setOnClickListener { scanQr() }

        findInput.doAfterTextChanged { t ->
            val q = t?.toString().orEmpty()
            if (q.isEmpty()) web().clearMatches() else web().findAllAsync(q)
        }
        findViewById<View>(R.id.findNext).setOnClickListener { web().findNext(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { web().findNext(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val w = web()
                when {
                    findBar.visibility == View.VISIBLE -> closeFind()
                    w.canGoBack() -> w.goBack()
                    tabs.size > 1 -> closeTab(cur)
                    else -> finish()
                }
            }
        })

        handleIncoming(intent)
    }

    override fun onStart() {
        super.onStart()
        checkLock()
    }

    override fun onStop() {
        super.onStop()
        stopAt = SystemClock.elapsedRealtime()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(i: Intent?) {
        val d = i?.data
        if (d == null) {
            if (tabs.isEmpty()) newTab(null)
        } else if (d.scheme == "content" || d.scheme == "file") {
            newTab(null); openFile(d)
        } else newTab(d.toString())
    }

    // ---------- Tabs ----------

    private fun web(): WebView = tabs[cur].web
    private fun isCur(v: WebView) = tabs.getOrNull(cur)?.web === v

    private fun newTab(url: String?, incognito: Boolean = false) {
        val t = Tab(makeWeb(incognito), incognito)
        tabs.add(t)
        show(tabs.lastIndex)
        t.web.loadUrl(url ?: HOME)
    }

    private fun showUrl(u: String?): String =
        if (u == null || u.startsWith("file:///android_asset") || u == "about:blank") "" else u

    private fun show(i: Int) {
        cur = i
        container.removeAllViews()
        val w = tabs[i].web
        (w.parent as? ViewGroup)?.removeView(w)
        container.addView(w, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        urlBar.setText(showUrl(w.url))
        tabCount.text = tabs.size.toString()
        topBar.setBackgroundColor(if (tabs[i].incognito) 0xFF3C4043.toInt() else 0xFFF1F3F4.toInt())
        progress.visibility = View.GONE
        refreshUi()
    }

    private fun closeTab(i: Int) {
        val t = tabs.removeAt(i)
        container.removeView(t.web)
        if (t.incognito) {
            t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData()
        }
        t.web.destroy()
        if (tabs.isEmpty()) newTab(null) else show(minOf(i, tabs.lastIndex))
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, t ->
            (if (i == cur) "● " else "") + (if (t.incognito) "🕶 " else "") + t.title
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("${tabs.size} tab")
            .setItems(names) { _, i -> show(i) }
            .setPositiveButton("New tab") { _, _ -> newTab(null) }
            .setNeutralButton("Incognito") { _, _ -> newTab(null, true) }
            .setNegativeButton("Close tab") { _, _ -> closeTab(cur) }
            .show()
    }

    // ---------- WebView ----------

    private fun makeWeb(incognito: Boolean): WebView {
        val w = WebView(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !isOn("tp_block"))
        w.settings.apply {
            javaScriptEnabled = prefs.getBoolean("js", true)
            domStorageEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            if (incognito) cacheMode = WebSettings.LOAD_NO_CACHE
            userAgentString = if (desktop) DESKTOP_UA else defaultUA
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) {
                val tab = tabs.firstOrNull { it.web === v }
                if (u != null && (u.startsWith("http") || u.startsWith("file"))) tab?.flag = 0
                if (u != null && isBlocked(u)) {
                    tab?.flag = 1
                    tab?.blockedUrl = u
                    v.stopLoading()
                    v.loadDataWithBaseURL(null, blockedPage(u), "text/html", "UTF-8", null)
                    return
                }
                if (isCur(v)) {
                    urlBar.setText(showUrl(u))
                    progress.visibility = View.VISIBLE
                    refreshUi()
                }
            }

            override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: SslError) {
                h.cancel()
                tabs.firstOrNull { it.web === v }?.flag = 2
                val why = when (e.primaryError) {
                    SslError.SSL_EXPIRED -> "Certificate-er meyad shesh"
                    SslError.SSL_IDMISMATCH -> "Certificate onno site-er, ei site-er na"
                    SslError.SSL_UNTRUSTED -> "Certificate authority bishwasyogyo na"
                    SslError.SSL_NOTYETVALID -> "Certificate ekhono valid hoyni"
                    else -> "Certificate-e somossha"
                }
                v.loadDataWithBaseURL(
                    null,
                    "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                            "<body style='font-family:sans-serif;text-align:center;padding:48px 24px;color:#202124'>" +
                            "<div style='font-size:56px'>⛔</div><h2>Connection private na</h2>" +
                            "<p><b>${Uri.parse(e.url).host}</b></p><p style='color:#d93025'>$why</p>" +
                            "<p style='color:#5f6368'>Attacker tomar data churi korte pare. Password, card ba OTP dio na. Site-ta chhere dao.</p></body></html>",
                    "text/html", "UTF-8", null
                )
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (isOn("adblock")) {
                    val h = r.url.host?.lowercase()
                    if (h != null && TRACKERS.any { h == it || h.endsWith(".$it") }) {
                        return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return null
            }

            override fun onPageFinished(v: WebView, u: String?) {
                if (isCur(v)) {
                    progress.visibility = View.GONE
                    refreshUi()
                }
                applyDark(v)
                val t = tabs.firstOrNull { it.web === v }
                if (t != null && !t.incognito && u != null && u.startsWith("http")) {
                    addHistory(v.title ?: u, u)
                }
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val s = u.scheme ?: return false
                if ((s == "unblock" || s == "safeoff") && tabs.firstOrNull { it.web === v }?.flag == 1) {
                    confirmUnblock(v, s, u.host ?: ""); return true
                }
                if (s == "http" && isOn("https_only") && u.host != "localhost") {
                    v.loadUrl(secureUrl(u.toString())); return true
                }
                if (s == "http" || s == "https" || s == "file" || s == "about" || s == "data") return false
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Onno app khulbe?")
                    .setMessage("Ei site onno app khulte chay (\"$s\"):\n$u")
                    .setPositiveButton("Open") { _, _ ->
                        try {
                            val i = if (s == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, u)
                            startActivity(i)
                        } catch (e: Exception) {
                            toast("Open kora jachche na")
                        }
                    }
                    .setNegativeButton("Block", null)
                    .show()
                return true
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (isCur(v)) progress.progress = p
            }

            override fun onReceivedIcon(v: WebView, icon: Bitmap?) {
                tabs.firstOrNull { it.web === v }?.icon = icon
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                tabs.firstOrNull { it.web === v }?.title = title ?: "New tab"
            }

            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val launch = {
                    try {
                        picker.launch(params.createIntent())
                    } catch (e: Exception) {
                        fileCb?.onReceiveValue(null); fileCb = null
                    }
                }
                val cancel = { fileCb?.onReceiveValue(null); fileCb = null }
                val cu = v.url ?: ""
                if (cu.startsWith("https") || cu.startsWith("file")) launch()
                else AlertDialog.Builder(this@MainActivity)
                    .setTitle("⚠️ Insecure site")
                    .setMessage("Ei site HTTPS na. File upload korle onno keu dekhte ba churi korte pare. Tobuo file dibe?")
                    .setPositiveButton("File dao") { _, _ -> launch() }
                    .setNegativeButton("Cancel") { _, _ -> cancel() }
                    .setOnCancelListener { cancel() }
                    .show()
                return true
            }

            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread { handleWebPerm(req) }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, cb: GeolocationPermissions.Callback
            ) {
                val mode = prefs.getString("perm_loc", "ask")
                if (mode == "block") {
                    cb.invoke(origin, false, false); return
                }
                val proceed = {
                    withAndroidPerms(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) { ok ->
                        cb.invoke(origin, ok, false)
                    }
                }
                if (mode == "allow") proceed()
                else AlertDialog.Builder(this@MainActivity)
                    .setTitle(Uri.parse(origin).host ?: origin)
                    .setMessage("Ei site tomar location chay")
                    .setPositiveButton("Allow") { _, _ -> proceed() }
                    .setNegativeButton("Block") { _, _ -> cb.invoke(origin, false, false) }
                    .setOnCancelListener { cb.invoke(origin, false, false) }
                    .show()
            }
        }
        w.setDownloadListener { url, ua, cd, mime, _ -> onDownload(url, ua, cd, mime) }
        return w
    }

    private fun download(url: String, ua: String, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mime)
                .addRequestHeader("User-Agent", ua)
                .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Download shuru: $name")
        } catch (e: Exception) {
            toast("Download fail")
        }
    }

    private fun searchUrl(q: String, engine: String): String {
        val enc = URLEncoder.encode(q, "UTF-8")
        return if (engine == "khoj") (prefs.getString("khoj_tpl", KHOJ_TPL) ?: KHOJ_TPL).replace("%s", enc)
        else "https://www.google.com/search?q=$enc"
    }

    // ---------- Add to Home screen (install app) ----------

    private fun letterIcon(name: String): Bitmap {
        val b = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF4285F4.toInt()
        c.drawCircle(96f, 96f, 96f, p)
        p.color = Color.WHITE
        p.textSize = 110f
        p.textAlign = Paint.Align.CENTER
        c.drawText(name.take(1).uppercase(), 96f, 134f, p)
        return b
    }

    private fun addToHome() {
        val t = tabs[cur]
        val url = t.web.url
        if (url == null || !url.startsWith("http")) {
            toast("Ei page home screen-e rakha jabe na"); return
        }
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toast("Ei launcher shortcut support kore na"); return
        }
        val host = Uri.parse(url).host ?: "App"
        val input = EditText(this).apply {
            setSingleLine(); setText(t.title.take(24))
        }
        AlertDialog.Builder(this)
            .setTitle("Home screen-e add koro")
            .setMessage(host)
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = input.text.toString().ifBlank { host }
                val icon = t.icon?.let { Bitmap.createScaledBitmap(it, 192, 192, true) } ?: letterIcon(name)
                val i = Intent(this, WebAppActivity::class.java)
                    .setAction(Intent.ACTION_VIEW).setData(Uri.parse(url))
                val info = ShortcutInfoCompat.Builder(this, "web_" + url.hashCode())
                    .setShortLabel(name)
                    .setIcon(IconCompat.createWithBitmap(icon))
                    .setIntent(i)
                    .build()
                ShortcutManagerCompat.requestPinShortcut(this, info, null)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEngine() {
        val curr = if (prefs.getString("engine", "google") == "khoj") 1 else 0
        AlertDialog.Builder(this)
            .setTitle("Default search engine")
            .setSingleChoiceItems(arrayOf("Google", "Khoj (tomar site)"), curr) { d, i ->
                prefs.edit().putString("engine", if (i == 1) "khoj" else "google").apply()
                toast(if (i == 1) "Default: Khoj" else "Default: Google")
                d.dismiss()
            }
            .setNeutralButton("Khoj URL edit") { _, _ -> editKhoj() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun editKhoj() {
        val input = EditText(this).apply {
            setSingleLine(); hint = "https://site/?q=%s"
            setText(prefs.getString("khoj_tpl", KHOJ_TPL))
        }
        AlertDialog.Builder(this)
            .setTitle("Khoj search URL (%s = search word)")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val t = input.text.toString().trim()
                if (t.contains("%s")) prefs.edit().putString("khoj_tpl", t).apply()
                else toast("URL-e %s thakte hobe")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toUrl(input: String): String {
        val s = input.trim()
        if (s.startsWith("k ")) return searchUrl(s.drop(2).trim(), "khoj")
        if (s.startsWith("g ")) return searchUrl(s.drop(2).trim(), "google")
        return when {
            s.contains("://") -> s
            !s.contains(" ") && s.contains(".") -> "https://$s"
            s.startsWith("localhost") -> "http://$s"
            else -> searchUrl(s, prefs.getString("engine", "google") ?: "google")
        }
    }

    private fun go(input: String) {
        if (input.isBlank()) return
        web().loadUrl(secureUrl(toUrl(input)))
        web().requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun refreshUi() {
        val w = web()
        btnBack.alpha = if (w.canGoBack()) 1f else 0.35f
        btnFwd.alpha = if (w.canGoForward()) 1f else 0.35f
        val cu = w.url ?: ""
        secIcon.text = when {
            tabs[cur].flag == 2 -> "⛔"
            tabs[cur].flag == 1 -> "🚫"
            cu.startsWith("https") -> "🔒"
            cu.startsWith("http") -> "⚠️"
            else -> "🏠"
        }
        val u = w.url
        val marked = u != null && load("bm").any { it.second == u }
        star.text = if (marked) "★" else "☆"
    }

    private fun applyDark(w: WebView) {
        val js = if (dark)
            "(function(){var s=document.getElementById('__d');if(!s){s=document.createElement('style');s.id='__d';document.head.appendChild(s);}" +
                    "s.textContent='html{filter:invert(1) hue-rotate(180deg)}img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)}';})()"
        else "var s=document.getElementById('__d');if(s)s.remove();"
        w.evaluateJavascript(js, null)
    }

    // ---------- Security: block sites & permissions ----------

    private fun isBlocked(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase()?.takeIf { it.isNotEmpty() } ?: return false
        if (load("block").any { it.first.isNotEmpty() && (host == it.first || host.endsWith("." + it.first)) }) return true
        if (prefs.getBoolean("safe", false) && ADULT_WORDS.any { host.contains(it) }) return true
        return false
    }

    private fun blockedPage(url: String): String {
        val host = Uri.parse(url).host ?: url
        val inList = load("block").any { host == it.first || host.endsWith("." + it.first) }
        val msg = if (inList) "Tumi ei site block koreccho." else "Safe mode on ache, tai ei site block."
        val link = (if (inList) "unblock://" else "safeoff://") + host
        val label = if (inList) "Unblock koro" else "Safe mode off koro"
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                "<body style='font-family:sans-serif;text-align:center;padding:48px 24px;color:#202124'>" +
                "<div style='font-size:56px'>🚫</div><h2>Site blocked</h2><p><b>$host</b></p>" +
                "<p style='color:#5f6368'>$msg</p>" +
                "<a href='$link' style='display:inline-block;margin-top:12px;padding:12px 26px;border-radius:24px;" +
                "background:#1a73e8;color:#fff;text-decoration:none;font-size:16px'>$label</a>" +
                "</body></html>"
    }

    private fun unblockHost(host: String) {
        val l = load("block")
        l.removeAll { host == it.first || host.endsWith("." + it.first) }
        save("block", l)
    }

    private fun confirmUnblock(v: WebView, scheme: String, host: String) {
        val tab = tabs.firstOrNull { it.web === v } ?: return
        AlertDialog.Builder(this)
            .setTitle(if (scheme == "unblock") "Unblock $host?" else "Safe mode off korbe?")
            .setPositiveButton("Yes") { _, _ ->
                if (scheme == "unblock") unblockHost(host) else prefs.edit().putBoolean("safe", false).apply()
                tab.blockedUrl?.let { v.loadUrl(it) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun mode(k: String) = prefs.getString(k, "ask") ?: "ask"

    private fun cycle(k: String) {
        val order = listOf("ask", "allow", "block")
        prefs.edit().putString(k, order[(order.indexOf(mode(k)) + 1) % 3]).apply()
    }

    private data class Opt(val key: String, val label: String, val def: Boolean)

    private val opts = listOf(
        Opt("js", "JavaScript", true),
        Opt("cookies", "Cookies", true),
        Opt("tp_block", "Third-party cookie block", true),
        Opt("https_only", "HTTPS-only mode", false),
        Opt("adblock", "Ads & tracker block", true),
        Opt("ask_file", "File-er age sotorko-barta (always)", true),
        Opt("dl_block", "Sob download block", false),
        Opt("safe", "Safe mode (adult site block)", false),
        Opt("noshot", "Screenshot & recent-apps block", false),
        Opt("applock", "App lock (phone PIN / fingerprint)", false),
        Opt("clear_exit", "App bondho hole data clear", false)
    )

    private fun isOn(key: String): Boolean =
        prefs.getBoolean(key, opts.firstOrNull { it.key == key }?.def ?: false)

    private fun secureUrl(u: String): String =
        if (isOn("https_only") && u.startsWith("http://") && !u.startsWith("http://localhost"))
            "https://" + u.removePrefix("http://") else u

    private fun toggleOpt(o: Opt) {
        val now = !isOn(o.key)
        if (o.key == "applock" && now) {
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                toast("Age phone-e screen lock (PIN/pattern) set koro"); return
            }
            unlocked = true
        }
        prefs.edit().putBoolean(o.key, now).apply()
        applyOpt(o.key, now)
    }

    private fun applyOpt(key: String, v: Boolean) {
        when (key) {
            "js" -> {
                tabs.forEach { it.web.settings.javaScriptEnabled = v }; web().reload()
            }
            "cookies" -> CookieManager.getInstance().setAcceptCookie(v)
            "tp_block" -> tabs.forEach { CookieManager.getInstance().setAcceptThirdPartyCookies(it.web, !v) }
            "noshot" -> applySecureFlag()
            "https_only", "adblock", "safe" -> web().reload()
        }
    }

    private fun applySecureFlag() {
        if (isOn("noshot")) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun checkLock() {
        if (!isOn("applock") || locking) return
        val away = SystemClock.elapsedRealtime() - stopAt
        if (!unlocked || (stopAt > 0 && away > 20_000)) {
            unlocked = false
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            val i = km.createConfirmDeviceCredentialIntent("Browser unlock", null)
            if (i == null) {
                unlocked = true; return
            }
            locking = true
            container.visibility = View.INVISIBLE
            lockLauncher.launch(i)
        }
    }

    private fun showSecurity() {
        val permKeys = listOf("perm_cam" to "Camera", "perm_mic" to "Microphone", "perm_loc" to "Location")
        val labels = mutableListOf("🛡 Security check (ki ki block korbo)")
        permKeys.forEach { labels.add("${it.second}: ${mode(it.first).uppercase()}") }
        opts.forEach { labels.add("${it.label}: ${if (isOn(it.key)) "ON" else "OFF"}") }
        labels.add("Block this site")
        labels.add("Blocked sites (list / add)")
        labels.add("Clear browsing data now")
        val o0 = 1 + permKeys.size
        val a0 = o0 + opts.size
        AlertDialog.Builder(this)
            .setTitle("Security & permissions")
            .setItems(labels.toTypedArray()) { _, i ->
                when {
                    i == 0 -> {
                        showCheckup(); return@setItems
                    }
                    i < o0 -> cycle(permKeys[i - 1].first)
                    i < a0 -> toggleOpt(opts[i - o0])
                    i == a0 -> {
                        val host = Uri.parse(web().url ?: "").host
                        if (host.isNullOrEmpty()) toast("Ei page block kora jabe na")
                        else {
                            blockHost(host); web().reload()
                        }
                        return@setItems
                    }
                    i == a0 + 1 -> {
                        showBlockList(); return@setItems
                    }
                    else -> {
                        clearData(); return@setItems
                    }
                }
                showSecurity()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showCheckup() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val checks = listOf(
            "Camera/Mic/Location 'Allow' kora nei" to
                    (mode("perm_cam") != "allow" && mode("perm_mic") != "allow" && mode("perm_loc") != "allow"),
            "Third-party cookie block (tracking kombe)" to isOn("tp_block"),
            "HTTPS-only mode (insecure site-e jabe na)" to isOn("https_only"),
            "Ads & tracker block" to isOn("adblock"),
            "File-er age sotorko-barta" to isOn("ask_file"),
            "Safe mode (adult/harmful site block)" to isOn("safe"),
            "App bondho hole data clear" to isOn("clear_exit"),
            "App lock" + (if (km.isDeviceSecure) "" else " (age phone-e screen lock dao)") to isOn("applock")
        )
        val score = checks.count { it.second }
        val msg = checks.joinToString("\n") { (if (it.second) "✅ " else "⚠️ ") + it.first } +
                "\n\nShob shomoy ON (bondho kora jay na):\n" +
                "✅ Google Safe Browsing (phishing/malware warning)\n" +
                "✅ Certificate error-e site block\n" +
                "✅ HTTP content HTTPS page-e block\n" +
                "✅ Popup block\n" +
                "✅ Local file access off\n" +
                "✅ Onno app khular age jiggesh\n\n" +
                "Tip: Banking/OTP-r shomoy Incognito + HTTPS (🔒) check koro, public WiFi-te login korio na."
        AlertDialog.Builder(this)
            .setTitle("Security check: $score/${checks.size}")
            .setMessage(msg)
            .setPositiveButton("Apply recommended") { _, _ -> applyRecommended() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun applyRecommended() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val e = prefs.edit()
        listOf("perm_cam", "perm_mic", "perm_loc").forEach { if (mode(it) == "allow") e.putString(it, "ask") }
        e.putBoolean("tp_block", true).putBoolean("https_only", true).putBoolean("adblock", true)
            .putBoolean("ask_file", true).putBoolean("safe", true).putBoolean("clear_exit", true)
        if (km.isDeviceSecure) {
            e.putBoolean("applock", true); unlocked = true
        }
        e.apply()
        tabs.forEach { CookieManager.getInstance().setAcceptThirdPartyCookies(it.web, false) }
        web().reload()
        toast("Recommended security ON kora hoyeche")
    }

    private fun showSiteInfo() {
        val w = web()
        val t = tabs[cur]
        val u = w.url ?: ""
        val host = Uri.parse(u).host
        val sb = StringBuilder()
        when {
            t.flag == 2 -> sb.append("⛔ Certificate-e somossha. Ei site-e kono tothyo dio na.\n")
            t.flag == 1 -> sb.append("🚫 Ei site block kora.\n")
            u.startsWith("https") -> {
                sb.append("🔒 Connection secure (HTTPS)\n")
                w.certificate?.let {
                    sb.append("Certificate: ").append(it.issuedBy?.oName ?: it.issuedBy?.cName ?: "?").append("\n")
                    sb.append("Meyad: ").append(it.validNotAfterDate).append("\n")
                }
            }
            u.startsWith("http") -> sb.append(
                "⚠️ NOT SECURE (HTTP)\nPassword, card, OTP ba personal tothyo dio na. " +
                        "Majhkhane keu data dekhte ba bodle dite pare. HTTPS-only mode ON kore dao.\n"
            )
            else -> sb.append("🏠 App-er nijossho page\n")
        }
        sb.append("\nEi site-er jonno ki ki block korte paro:\n")
        sb.append("• Camera: ${mode("perm_cam").uppercase()}, Mic: ${mode("perm_mic").uppercase()}, Location: ${mode("perm_loc").uppercase()}\n")
        sb.append("• Third-party cookie: ${if (isOn("tp_block")) "block" else "ALLOWED (block korle bhalo)"}\n")
        sb.append("• Ads/tracker: ${if (isOn("adblock")) "block" else "ALLOWED (block korle bhalo)"}\n")
        sb.append("• Site-ta bishwasyogyo na hole 'Block this site' dao.")
        val b = AlertDialog.Builder(this)
            .setTitle(host ?: "Site info")
            .setMessage(sb.toString())
            .setNeutralButton("Security settings") { _, _ -> showSecurity() }
            .setNegativeButton("Close", null)
        if (!host.isNullOrEmpty()) b.setPositiveButton("Block this site") { _, _ -> blockHost(host); web().reload() }
        b.show()
    }

    private fun clearData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tabs.forEach { it.web.clearCache(true); it.web.clearFormData() }
        save("hist", emptyList())
        toast("Browsing data clear")
    }

    // ---------- File safety ----------

    // 2 = bipodjonok, 1 = shotorko, 0 = normal
    private fun fileRisk(name: String): Int {
        val ext = name.substringAfterLast('.', "").lowercase()
        val high = setOf(
            "apk", "xapk", "apkm", "exe", "msi", "bat", "cmd", "com", "scr", "vbs", "ps1", "jar",
            "sh", "dll", "dmg", "pkg", "lnk", "reg", "docm", "xlsm", "pptm"
        )
        val mid = setOf(
            "zip", "rar", "7z", "tar", "gz", "iso", "doc", "xls", "ppt", "docx", "xlsx", "pptx",
            "pdf", "js", "html", "htm", "svg", "py"
        )
        return when (ext) {
            in high -> 2
            in mid -> 1
            else -> 0
        }
    }

    private fun onDownload(url: String, ua: String, cd: String?, mime: String?) {
        if (isOn("dl_block")) {
            toast("Download block kora ache (Security theke on/off kora jay)"); return
        }
        val name = URLUtil.guessFileName(url, cd, mime)
        val risk = fileRisk(name)
        val insecure = !url.startsWith("https")
        val isPdf = mime == "application/pdf" || url.substringBefore('?').lowercase().endsWith(".pdf")
        if (!isOn("ask_file") && risk == 0 && !insecure && !isPdf) {
            download(url, ua, cd, mime); return
        }
        val msg = StringBuilder("File: $name\nSite: ${Uri.parse(url).host}\n\n")
        when (risk) {
            2 -> msg.append("🚨 BIPODJONOK file type! Eta install ba run hole phone-er khoti, data churi ba virus hote pare. Sure na hole download korio na.")
            1 -> msg.append("⚠️ Shotorko hou: Archive, Office, PDF ba HTML file-e virus ba phishing thakte pare. Unknown source hole kholo na.")
            else -> msg.append("Download-er age nishchit hou site-ta bishwasyogyo.")
        }
        if (insecure) msg.append("\n\n🔓 Ei site HTTPS na, file raste bodle jete pare.")
        val b = AlertDialog.Builder(this)
            .setTitle("File security")
            .setMessage(msg.toString())
            .setNegativeButton("Cancel", null)
        if (isPdf) {
            b.setPositiveButton("Open") { _, _ -> fetchPdf(url, ua) }
            b.setNeutralButton("Download") { _, _ -> download(url, ua, cd, mime) }
        } else {
            b.setPositiveButton(if (risk == 2) "Download anyway" else "Download") { _, _ -> download(url, ua, cd, mime) }
        }
        b.show()
    }

    private fun blockHost(h: String) {
        val host = h.lowercase().removePrefix("www.")
        if (host.isBlank()) {
            toast("Ei page block kora jabe na"); return
        }
        val l = load("block")
        if (l.none { it.first == host }) {
            l.add(0, host to host); save("block", l)
        }
        toast("Block: $host")
    }

    private fun showBlockList() {
        val l = load("block")
        val b = AlertDialog.Builder(this)
            .setTitle("Blocked sites (tap = unblock)")
            .setPositiveButton("Add site") { _, _ ->
                val input = EditText(this).apply { hint = "example.com"; setSingleLine() }
                AlertDialog.Builder(this)
                    .setTitle("Site block koro")
                    .setView(input)
                    .setPositiveButton("Block") { _, _ ->
                        val t = input.text.toString().trim()
                        if (t.isNotEmpty()) blockHost(Uri.parse(if (t.contains("://")) t else "https://$t").host ?: t)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Close", null)
        if (l.isEmpty()) b.setMessage("Kono site block kora nei.")
        else {
            b.setItems(l.map { it.first }.toTypedArray()) { _, i ->
                l.removeAt(i); save("block", l); toast("Unblocked")
                val t = tabs[cur]
                t.blockedUrl?.let { u -> if (t.flag == 1 && !isBlocked(u)) t.web.loadUrl(u) }
            }
            b.setNeutralButton("Unblock all") { _, _ ->
                save("block", emptyList()); toast("Shob unblock")
                val t = tabs[cur]
                t.blockedUrl?.let { u -> if (t.flag == 1 && !isBlocked(u)) t.web.loadUrl(u) }
            }
        }
        b.show()
    }

    private fun withAndroidPerms(p: Array<String>, cb: (Boolean) -> Unit) {
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) cb(true)
        else {
            pendingPerm = cb; permLauncher.launch(p)
        }
    }

    private fun handleWebPerm(req: PermissionRequest) {
        val cam = PermissionRequest.RESOURCE_VIDEO_CAPTURE
        val mic = PermissionRequest.RESOURCE_AUDIO_CAPTURE
        val needs = req.resources.filter { it == cam || it == mic }
        if (needs.isEmpty()) {
            req.deny(); return
        }
        val modes = needs.map { mode(if (it == cam) "perm_cam" else "perm_mic") }
        if (modes.contains("block")) {
            req.deny(); return
        }
        val android = needs.map {
            if (it == cam) Manifest.permission.CAMERA else Manifest.permission.RECORD_AUDIO
        }.toTypedArray()
        val proceed = {
            withAndroidPerms(android) { ok ->
                if (ok) req.grant(needs.toTypedArray()) else req.deny()
            }
        }
        if (modes.all { it == "allow" }) proceed()
        else {
            val what = needs.joinToString(" + ") { if (it == cam) "camera" else "microphone" }
            AlertDialog.Builder(this)
                .setTitle(req.origin.host ?: "Site")
                .setMessage("Ei site $what use korte chay")
                .setPositiveButton("Allow") { _, _ -> proceed() }
                .setNegativeButton("Block") { _, _ -> req.deny() }
                .setOnCancelListener { req.deny() }
                .show()
        }
    }

    // ---------- Menu ----------

    private fun showMenu() {
        val items = arrayOf(
            "New tab",
            "New incognito tab",
            "Bookmarks",
            "History",
            "Downloads",
            "Find in page",
            "Desktop site" + if (desktop) "  ✓" else "",
            "Dark mode (pages)" + if (dark) "  ✓" else "",
            "Share",
            "Clear history",
            "Scan QR code",
            "Run HTML / JS code",
            "Dictionary",
            "Open file (PDF, image, video, code...)",
            "Security & permissions",
            "Search engine (Google / Khoj)",
            "Add to Home screen (install app)"
        )
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> newTab(null)
                1 -> newTab(null, true)
                2 -> showList("Bookmarks", "bm")
                3 -> showList("History", "hist")
                4 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                5 -> {
                    findBar.visibility = View.VISIBLE
                    findInput.requestFocus()
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(findInput, 0)
                }
                6 -> {
                    desktop = !desktop
                    tabs.forEach { it.web.settings.userAgentString = if (desktop) DESKTOP_UA else defaultUA }
                    web().reload()
                }
                7 -> {
                    dark = !dark
                    tabs.forEach { applyDark(it.web) }
                }
                8 -> {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, web().url ?: "")
                    }
                    startActivity(Intent.createChooser(send, "Share"))
                }
                9 -> {
                    save("hist", emptyList()); toast("History clear")
                }
                10 -> scanQr()
                11 -> showCodeRunner()
                12 -> showDictionary()
                13 -> openDoc.launch(arrayOf("*/*"))
                14 -> showSecurity()
                15 -> showEngine()
                16 -> addToHome()
            }
        }.show()
    }

    private fun closeFind() {
        web().clearMatches()
        findInput.setText("")
        findBar.visibility = View.GONE
    }

    // ---------- QR scanner & code runner ----------

    private fun scanQr() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .enableAutoZoom()
            .build()
        GmsBarcodeScanning.getClient(this, options).startScan()
            .addOnSuccessListener { b -> handleScanned(b.rawValue.orEmpty()) }
            .addOnFailureListener {
                Toast.makeText(this, "Scan hoyni (Google Play services lagbe)", Toast.LENGTH_LONG).show()
            }
    }

    private fun handleScanned(text: String) {
        if (text.isBlank()) return
        val t = text.trim()
        if (t.startsWith("<")) {
            runCode(t)
        } else {
            AlertDialog.Builder(this)
                .setTitle("QR result")
                .setMessage(t)
                .setPositiveButton("Open") { _, _ -> newTab(toUrl(t)) }
                .setNeutralButton("Copy") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("qr", t))
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }

    private fun showCodeRunner() {
        val input = EditText(this).apply {
            hint = "<h1>Hello</h1>  ba  alert('hi')"
            setHorizontallyScrolling(false)
            minLines = 8
            gravity = Gravity.TOP
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setText(prefs.getString("lastCode", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("HTML / CSS / JS run koro")
            .setView(input)
            .setPositiveButton("Run") { _, _ ->
                val code = input.text.toString()
                prefs.edit().putString("lastCode", code).apply()
                runCode(code)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // "<" diye shuru hole HTML, na hole JavaScript hishebe run hobe
    private fun runCode(code: String) {
        val c = code.trim()
        if (c.isEmpty()) return
        val html = if (c.startsWith("<")) c
        else "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                "<body style='font-family:monospace'><script>$c</script></body></html>"
        newTab("about:blank")
        web().loadDataWithBaseURL("https://run.local/", html, "text/html", "UTF-8", null)
    }

    // ---------- Dictionary ----------

    private fun showDictionary() {
        web().evaluateJavascript("(window.getSelection()||'').toString()") { raw ->
            val sel = try {
                if (raw == null || raw == "null") "" else JSONArray("[$raw]").getString(0).trim()
            } catch (e: Exception) {
                ""
            }
            openDictionary(sel)
        }
    }

    private fun openDictionary(initial: String) {
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val word = EditText(this).apply {
            hint = "English word"; setSingleLine(); setText(initial.take(40))
        }
        val result = TextView(this).apply {
            textSize = 15f; setPadding(0, pad / 2, 0, 0)
        }
        val sv = ScrollView(this).apply { addView(result) }
        box.addView(word)
        box.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (300 * d).toInt()))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Dictionary")
            .setView(box)
            .setPositiveButton("Search", null)
            .setNeutralButton("Bangla") { _, _ ->
                newTab(
                    "https://translate.google.com/?sl=en&tl=bn&op=translate&text=" +
                            URLEncoder.encode(word.text.toString(), "UTF-8")
                )
            }
            .setNegativeButton("Close", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                lookup(word.text.toString().trim(), result)
            }
            if (initial.isNotBlank()) lookup(initial.trim(), result)
        }
        dlg.show()
    }

    private fun lookup(w: String, out: TextView) {
        if (w.isEmpty()) return
        out.text = "Khujchi..."
        Thread {
            val text = try {
                val c = URL("https://api.dictionaryapi.dev/api/v2/entries/en/" + URLEncoder.encode(w, "UTF-8"))
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode != 200) "Pawa jayni: $w"
                else {
                    val arr = JSONArray(c.inputStream.bufferedReader().readText())
                    val sb = StringBuilder()
                    val meanings = arr.getJSONObject(0).getJSONArray("meanings")
                    for (i in 0 until meanings.length()) {
                        val m = meanings.getJSONObject(i)
                        sb.append("• ").append(m.getString("partOfSpeech")).append("\n")
                        val defs = m.getJSONArray("definitions")
                        for (j in 0 until minOf(2, defs.length())) {
                            val df = defs.getJSONObject(j)
                            sb.append("   ").append(df.getString("definition")).append("\n")
                            if (df.has("example")) sb.append("   e.g. ").append(df.getString("example")).append("\n")
                        }
                        sb.append("\n")
                    }
                    sb.toString()
                }
            } catch (e: Exception) {
                "Internet lagbe ba kono error hoyeche"
            }
            runOnUiThread { out.text = text }
        }.start()
    }

    // ---------- Open any file ----------

    private fun queryName(u: Uri): String {
        val n = try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
        return n ?: (u.lastPathSegment ?: "")
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun openFile(u: Uri) {
        val mime = contentResolver.getType(u) ?: ""
        val name = queryName(u)
        val ext = name.substringAfterLast('.', "").lowercase()
        val textExt = setOf(
            "txt", "md", "json", "xml", "csv", "log", "kt", "java", "py", "ts", "c", "cpp", "h", "cs",
            "php", "rb", "go", "rs", "swift", "sql", "sh", "css", "yml", "yaml", "ini", "bat", "dart", "lua", "r"
        )
        when {
            mime == "application/pdf" || ext == "pdf" -> copyThen(u) { showPdf(it) }
            mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/") ->
                newTab(u.toString())
            ext == "html" || ext == "htm" || ext == "js" -> readTextThen(u) { runCode(it) }
            ext in textExt || mime.startsWith("text/") -> readTextThen(u) { t ->
                newTab("about:blank")
                web().loadDataWithBaseURL(
                    null,
                    "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                            "<body style='margin:8px'><pre style='font-size:13px;white-space:pre-wrap;word-break:break-word'>" +
                            esc(t) + "</pre></body></html>",
                    "text/html", "UTF-8", null
                )
            }
            else -> openExternal(u, mime)
        }
    }

    private fun openExternal(u: Uri, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(u, mime.ifBlank { "*/*" })
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Open with"))
        } catch (e: Exception) {
            toast("Ei file open korar app nei (Excel/PPT-r jonno WPS ba Office lagbe)")
        }
    }

    private fun readTextThen(u: Uri, cb: (String) -> Unit) {
        Thread {
            val t = try {
                contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }.take(2_000_000)
            } catch (e: Exception) {
                null
            }
            runOnUiThread { if (t == null) toast("File pora jayni") else cb(t) }
        }.start()
    }

    private fun copyThen(u: Uri, cb: (File) -> Unit) {
        Thread {
            val f = File(cacheDir, "view.pdf")
            val ok = try {
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread { if (ok) cb(f) else toast("File pora jayni") }
        }.start()
    }

    private fun fetchPdf(url: String, ua: String) {
        toast("PDF load hocche...")
        Thread {
            val f = File(cacheDir, "view.pdf")
            val ok = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.setRequestProperty("User-Agent", ua)
                CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread { if (ok) showPdf(f) else toast("PDF load hoyni") }
        }.start()
    }

    private fun showPdf(file: File) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val r = PdfRenderer(pfd)
            val width = resources.displayMetrics.widthPixels
            val rv = RecyclerView(this)
            rv.layoutManager = LinearLayoutManager(this)
            rv.setBackgroundColor(Color.DKGRAY)
            rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun getItemCount() = r.pageCount
                override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                    val iv = ImageView(p.context).apply {
                        layoutParams = RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        adjustViewBounds = true
                        setPadding(0, 0, 0, 8)
                    }
                    return object : RecyclerView.ViewHolder(iv) {}
                }

                override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                    synchronized(r) {
                        val pg = r.openPage(pos)
                        val bh = (width.toFloat() * pg.height / pg.width).toInt()
                        val bmp = Bitmap.createBitmap(width, bh, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        pg.close()
                        (h.itemView as ImageView).setImageBitmap(bmp)
                    }
                }
            }
            Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen).apply {
                setContentView(rv)
                setOnDismissListener {
                    try {
                        r.close(); pfd.close()
                    } catch (_: Exception) {
                    }
                }
                show()
            }
        } catch (e: Exception) {
            toast("PDF open kora jayni")
        }
    }

    // ---------- Bookmarks & history ----------

    private fun load(k: String): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val a = JSONArray(prefs.getString(k, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(o.getString("t") to o.getString("u"))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        prefs.edit().putString(k, a.toString()).apply()
    }

    private fun addHistory(title: String, url: String) {
        val l = load("hist")
        if (l.firstOrNull()?.second == url) return
        l.add(0, title to url)
        save("hist", l.take(300))
    }

    private fun toggleBookmark() {
        val w = web()
        val u = w.url ?: return
        val l = load("bm")
        val idx = l.indexOfFirst { it.second == u }
        if (idx >= 0) {
            l.removeAt(idx); toast("Bookmark remove")
        } else {
            l.add(0, (w.title ?: u) to u); toast("Bookmark kora hoyeche")
        }
        save("bm", l)
        refreshUi()
    }

    private fun showList(title: String, key: String) {
        val items = load(key)
        if (items.isEmpty()) {
            toast("Khali"); return
        }
        val labels = items.map { p -> p.first.ifBlank { p.second } + "\n" + p.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, i -> go(items[i].second) }
            .setNeutralButton("Clear all") { _, _ -> save(key, emptyList()); refreshUi() }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onDestroy() {
        if (isOn("clear_exit")) clearData()
        tabs.forEach { it.web.destroy() }
        super.onDestroy()
    }
}
